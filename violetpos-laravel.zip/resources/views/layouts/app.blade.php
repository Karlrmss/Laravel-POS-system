<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="VioletPOS — a Laravel point-of-sale account dashboard.">
    <title>@yield('title', 'Dashboard') · VioletPOS</title>
    <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <header class="site-header">
        <div class="nav-shell">
            <a class="brand" href="{{ route('home') }}" aria-label="VioletPOS home">
                <span class="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 32 32" role="img"><path d="M8 7.5h16l-1.8 17H9.8L8 7.5Z"/><path d="M12 10V6.7C12 4.7 13.8 3 16 3s4 1.7 4 3.7V10"/></svg>
                </span>
                <span>Violet<span>POS</span></span>
            </a>

            <nav class="main-nav" aria-label="Main navigation">
                <a href="{{ route('home') }}" @class(['active' => request()->routeIs('home')])>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.8 12 3l9 7.8v9.7a.5.5 0 0 1-.5.5h-5v-7h-7v7h-5a.5.5 0 0 1-.5-.5v-9.7Z"/></svg>Home
                </a>
                <a href="{{ route('customers.index') }}" @class(['active' => request()->routeIs('customers.*')])>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 20v-1.7c0-2-1.8-3.8-4-3.8H6c-2.2 0-4 1.8-4 3.8V20M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm8-2a3 3 0 0 1 0 6m2 5v-1.7c0-1.5-.8-2.8-2-3.4"/></svg>Customers
                </a>
                <a href="{{ route('users.index') }}" @class(['active' => request()->routeIs('users.*')])>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>Users
                </a>
                <a href="{{ route('about') }}" @class(['active' => request()->routeIs('about')])>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/></svg>About
                </a>
            </nav>

            <div class="profile-chip" aria-label="Signed in as Karl Ramos">
                <span class="avatar avatar-small">KR</span>
                <span class="profile-copy"><strong>Karl Ramos</strong><small>Administrator</small></span>
                <span class="chevron">⌄</span>
            </div>
        </div>
    </header>

    <main>@yield('content')</main>

    <footer class="site-footer">
        <div class="page-shell footer-inner">
            <a class="brand brand-footer" href="{{ route('home') }}">
                <span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M8 7.5h16l-1.8 17H9.8L8 7.5Z"/><path d="M12 10V6.7C12 4.7 13.8 3 16 3s4 1.7 4 3.7V10"/></svg></span>
                <span>Violet<span>POS</span></span>
            </a>
            <p>Built with Laravel &amp; Blade · MVC Laboratory Exercise</p>
            <p>© {{ date('Y') }} VioletPOS</p>
        </div>
    </footer>
    <script src="{{ asset('js/app.js') }}" defer></script>
</body>
</html>
